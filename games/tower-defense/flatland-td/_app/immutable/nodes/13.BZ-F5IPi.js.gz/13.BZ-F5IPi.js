import{at as a}from"../chunks/BK78c9Tw.js";export{a as component};
